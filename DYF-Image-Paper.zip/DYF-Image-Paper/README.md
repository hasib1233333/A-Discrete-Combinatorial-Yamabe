# Discrete Combinatorial Yamabe Flow Image Operator — reference implementation

This folder reproduces every figure, table, and number reported in
`paper_v2.pdf` / `paper_v2.tex`.

## Contents
- `code/yamabe_image.py` — core operator: Union-Jack triangulation,
  induced metric, discrete curvature, combinatorial Yamabe flow,
  multiplicative and graph-Poisson reconstruction.
- `code/make_figures.py` — generates the illustrative figures
  (mesh schematic, curvature battery, checkerboard corners, flattening
  flow, energy convergence, enhancement flow, edge-map comparison).
- `code/evaluation.py` — generates all quantitative benchmarks:
  single-image and eight-image denoising (PSNR/SSIM vs. Gaussian blur /
  bilateral / non-local means / wavelet / BM3D), corner detection
  (precision/recall/F1 vs. Harris / FAST / ORB on a synthetic
  ground-truth scene), objective no-reference sharpness metrics
  (variance-of-Laplacian, Tenengrad) for the enhancement flow, runtime
  and memory scaling, and stage-by-stage profiling. Writes all LaTeX
  tables used in the paper to `tables/`.
- `figs/` — all figures as vector PDFs, exactly as embedded in the paper.
- `tables/` — generated LaTeX table fragments.
- `paper_v3.tex`, `paper_v3.pdf` — the paper itself (current revision;
  corresponding author Gene Eu Jan, geneeujan@asia.edu.tw).

## A note on dataset scope
Standard benchmark corpora (BSD500, Kodak24, CBSD68, Set12, Urban100,
LIVE, HPatches) are **not** used in this study: they are not reachable
from the sandboxed environment this code was developed in (network
egress is restricted to software package registries), and none of them
ship as installable packages. The denoising benchmark is instead run on
one image and, separately, on eight diverse scikit-image sample images;
the corner-detection benchmark uses one synthetic scene with exact
ground truth. This is disclosed as the paper's main open limitation
(see Discussion section) rather than papered over. If you have access
to these corpora, `code/evaluation.py` is structured so that swapping
in a real image loader for `STD_IMAGES` / `load_gray()` and the
denoising/corner-detection loops is the only change needed to extend
the benchmark.

## Requirements
```
numpy
scipy
matplotlib
scikit-image
opencv-python
bm3d
```
Install with:
```
pip install numpy scipy matplotlib scikit-image opencv-python bm3d
```

## Reproducing everything
```
cd code
python3 make_figures.py     # writes ../figs/*.pdf
python3 evaluation.py       # writes ../figs/*.pdf and ../tables/*.tex
cd ..
pdflatex paper_v3.tex && pdflatex paper_v3.tex && pdflatex paper_v3.tex
```
All figures/tables are generated directly from real computations
(synthetic primitives + small crops of the scikit-image sample images);
no external dataset download is required or attempted.

## Recommended for publication
For camera-ready / post-acceptance release, archive this folder on
GitHub and mint a Zenodo DOI (Zenodo's GitHub integration does this
automatically on a tagged release), then cite the DOI in the paper's
Code Availability statement in place of "supplementary material".

## License
Provided for review and reproducibility purposes; add your preferred
open-source license (e.g. MIT or BSD-3-Clause) before public release.
