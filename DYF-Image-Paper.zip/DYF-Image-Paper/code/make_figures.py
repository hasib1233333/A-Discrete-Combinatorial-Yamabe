import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import cm
import skimage.data as skd
from skimage.transform import resize
from scipy import ndimage as ndi

from yamabe_image import (build_triangles, vertex_grid_coords, yamabe_flow,
                           reconstruct_image, edge_lengths_for_triangles,
                           triangle_angles, vertex_curvature, interior_mask_for)

FIGDIR = '/home/claude/paper/figs/'
plt.rcParams.update({'font.size': 9, 'figure.dpi': 170})

# ------------------------------------------------------------------
# Figure 1: mesh construction schematic
# ------------------------------------------------------------------
def fig_mesh_schematic():
    H, W = 4, 4
    tri = build_triangles(H, W)
    r, c = vertex_grid_coords(H, W)
    fig, ax = plt.subplots(figsize=(3.4, 3.4))
    for t in tri:
        pts = np.array([[c[v], -r[v]] for v in t] + [[c[t[0]], -r[t[0]]]])
        ax.plot(pts[:, 0], pts[:, 1], color='#4477AA', lw=1.1, zorder=1)
    ax.scatter(c, -r, color='#222222', s=28, zorder=2)
    vc = 1 * W + 1
    ax.scatter([c[vc]], [-r[vc]], color='#CC3311', s=70, zorder=3)
    ax.annotate('$v$', (c[vc], -r[vc]), textcoords="offset points",
                xytext=(8, 6), color='#CC3311', fontsize=12)
    ax.set_aspect('equal'); ax.axis('off')
    ax.set_title('Union--Jack triangulation of the pixel grid')
    fig.tight_layout()
    fig.savefig(FIGDIR + 'mesh_schematic.pdf')
    plt.close(fig)


# ------------------------------------------------------------------
# Figure 2: curvature response on synthetic primitives
# ------------------------------------------------------------------
def synthetic_battery():
    H = W = 40
    yy, xx = np.mgrid[0:H, 0:W]

    flat = np.full((H, W), 120.0)

    step = np.zeros((H, W)); step[:, W // 2:] = 200.0

    corner = np.zeros((H, W)); corner[H // 2:, W // 2:] = 200.0

    blob = 200 * np.exp(-(((yy - H / 2) ** 2 + (xx - W / 2) ** 2)) / (2 * 5.0 ** 2))

    rng = np.random.default_rng(0)
    noisy = 120 + 25 * rng.standard_normal((H, W))
    noisy = np.clip(noisy, 0, 255)

    return {'flat': flat, 'step edge': step, 'corner': corner,
            'Gaussian blob': blob, 'noise': noisy}


def fig_curvature_battery():
    imgs = synthetic_battery()
    fig, axes = plt.subplots(2, len(imgs), figsize=(2.15 * len(imgs), 4.4))
    for j, (name, im) in enumerate(imgs.items()):
        H, W = im.shape
        res = yamabe_flow(H, W, im.ravel(), lam=0.35, target='flat',
                           n_steps=1, dt=0.0)
        K0 = res['K0'].reshape(H, W)
        vmax = max(1e-6, np.nanmax(np.abs(K0[2:-2, 2:-2])))
        axes[0, j].imshow(im, cmap='gray'); axes[0, j].set_title(name, fontsize=8)
        axes[0, j].axis('off')
        m = axes[1, j].imshow(K0, cmap='RdBu_r', vmin=-vmax, vmax=vmax)
        axes[1, j].axis('off')
    axes[0, 0].set_ylabel('image', fontsize=8)
    axes[1, 0].set_ylabel('curvature $K$', fontsize=8)
    fig.suptitle('Combinatorial curvature $K_v$ of the image graph-surface', y=1.02)
    fig.tight_layout()
    fig.savefig(FIGDIR + 'curvature_battery.pdf', bbox_inches='tight')
    plt.close(fig)


# ------------------------------------------------------------------
# Figure 3: flattening flow (denoising) on a noisy patch, + energy curve
# ------------------------------------------------------------------
def fig_flattening_flow():
    H = W = 48
    rng = np.random.default_rng(1)
    yy, xx = np.mgrid[0:H, 0:W]
    clean = 60 + 140 * (((xx - W / 2) ** 2 + (yy - H / 2) ** 2) < 15 ** 2)
    clean = ndi.gaussian_filter(clean.astype(float), 1.0)
    noisy = np.clip(clean + 22 * rng.standard_normal((H, W)), 0, 255)

    res = yamabe_flow(H, W, noisy.ravel(), lam=0.30, target='flat',
                       n_steps=60, dt=0.05)
    snaps_idx = [0, 1, 3, 6]
    fig, axes = plt.subplots(1, len(snaps_idx) + 1, figsize=(3.0 * (len(snaps_idx) + 1), 3.0))
    axes[0].imshow(noisy, cmap='gray', vmin=0, vmax=255)
    axes[0].set_title('input (noisy)'); axes[0].axis('off')
    for k, si in enumerate(snaps_idx):
        u = res['u_hist'][min(si, len(res['u_hist']) - 1)]
        rec = reconstruct_image(noisy, u, H, W, beta=0.9)
        t_shown = si * (60 // 6)
        axes[k + 1].imshow(rec, cmap='gray', vmin=0, vmax=255)
        axes[k + 1].set_title(f'$t={t_shown}$')
        axes[k + 1].axis('off')
    fig.suptitle('Flattening flow ($\\bar K=0$): progressive structure-preserving smoothing', y=1.03)
    fig.tight_layout()
    fig.savefig(FIGDIR + 'flattening_flow.pdf', bbox_inches='tight')
    plt.close(fig)

    fig2, ax = plt.subplots(figsize=(3.4, 2.6))
    ax.plot(res['energy_hist'], color='#CC3311', lw=1.8)
    ax.set_xlabel('flow iteration $t$')
    ax.set_ylabel(r'$E(t)=\sum_v (K_v(t)-\bar K_v)^2$')
    ax.set_title('Monotone decrease of the Yamabe energy')
    ax.grid(alpha=0.3)
    fig2.tight_layout()
    fig2.savefig(FIGDIR + 'energy_convergence.pdf')
    plt.close(fig2)
    return noisy, clean, res


# ------------------------------------------------------------------
# Figure 4: enhancement flow (curvature-amplifying) on cameraman crop
# ------------------------------------------------------------------
def fig_enhancement_flow():
    cam = resize(skd.camera(), (96, 96), anti_aliasing=True) * 255
    H, W = cam.shape
    res = yamabe_flow(H, W, cam.ravel(), lam=0.35, target='amp', amp=2.2,
                       n_steps=25, dt=0.03)
    rec = reconstruct_image(cam, res['u'], H, W, beta=0.55)

    fig, axes = plt.subplots(1, 3, figsize=(8.4, 3.0))
    axes[0].imshow(cam, cmap='gray', vmin=0, vmax=255); axes[0].set_title('input')
    axes[1].imshow(res['u'].reshape(H, W), cmap='RdBu_r'); axes[1].set_title('conformal factor $u$')
    axes[2].imshow(rec, cmap='gray', vmin=0, vmax=255); axes[2].set_title('curvature-amplifying output')
    for a in axes: a.axis('off')
    fig.suptitle('Enhancement flow ($\\bar K = 2.2\\,K(0)$): structure-selective sharpening', y=1.02)
    fig.tight_layout()
    fig.savefig(FIGDIR + 'enhancement_flow.pdf', bbox_inches='tight')
    plt.close(fig)
    return cam, res, rec


# ------------------------------------------------------------------
# Figure 5: curvature edge/corner map vs Sobel / Laplacian (qualitative)
# ------------------------------------------------------------------
def fig_edge_comparison():
    cam = resize(skd.camera(), (110, 110), anti_aliasing=True) * 255
    H, W = cam.shape
    res = yamabe_flow(H, W, cam.ravel(), lam=0.4, target='flat', n_steps=1, dt=0.0)
    K0 = np.nan_to_num(res['K0']).reshape(H, W)

    sob = ndi.sobel(cam, axis=0) ** 2 + ndi.sobel(cam, axis=1) ** 2
    sob = np.sqrt(sob)
    lap = ndi.gaussian_laplace(cam, sigma=1.0)

    fig, axes = plt.subplots(1, 4, figsize=(11, 3.0))
    axes[0].imshow(cam, cmap='gray'); axes[0].set_title('input')
    axes[1].imshow(sob, cmap='gray'); axes[1].set_title('Sobel gradient magnitude')
    axes[2].imshow(np.abs(lap), cmap='gray'); axes[2].set_title('$|$Laplacian-of-Gaussian$|$')
    vmax = np.nanpercentile(np.abs(K0), 99)
    axes[3].imshow(np.abs(K0), cmap='gray', vmax=vmax); axes[3].set_title('$|K|$ (ours, geometric)')
    for a in axes: a.axis('off')
    fig.suptitle('Qualitative comparison of structural maps (no benchmark implied)', y=1.03)
    fig.tight_layout()
    fig.savefig(FIGDIR + 'edge_comparison.pdf', bbox_inches='tight')
    plt.close(fig)


# ------------------------------------------------------------------
# Figure 6: corner-detection illustration (checkerboard)
# ------------------------------------------------------------------
def fig_corner_checkerboard():
    chk = resize(skd.checkerboard(), (64, 64), anti_aliasing=False, order=0) * 255
    H, W = chk.shape
    res = yamabe_flow(H, W, chk.ravel(), lam=0.4, target='flat', n_steps=1, dt=0.0)
    K0 = np.nan_to_num(res['K0']).reshape(H, W)
    fig, axes = plt.subplots(1, 2, figsize=(5.6, 3.0))
    axes[0].imshow(chk, cmap='gray'); axes[0].set_title('checkerboard')
    vmax = np.nanmax(np.abs(K0))
    axes[1].imshow(K0, cmap='RdBu_r', vmin=-vmax, vmax=vmax)
    axes[1].set_title('$K$: corners as curvature dipoles')
    for a in axes: a.axis('off')
    fig.tight_layout()
    fig.savefig(FIGDIR + 'corner_checkerboard.pdf', bbox_inches='tight')
    plt.close(fig)


if __name__ == '__main__':
    fig_mesh_schematic()
    fig_curvature_battery()
    fig_flattening_flow()
    fig_enhancement_flow()
    fig_edge_comparison()
    fig_corner_checkerboard()
    print('all figures written to', FIGDIR)
