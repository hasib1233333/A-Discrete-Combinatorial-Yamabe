"""
Discrete Combinatorial Yamabe Flow for Grayscale Images (DYF-Im)
------------------------------------------------------------------
Reference implementation used to generate every numerical figure in the
paper "A Discrete Combinatorial Yamabe Flow Operator for Grayscale Image
Structure Analysis".  No external datasets are used: all inputs are
either synthetic test patterns or single classical test images bundled
with scikit-image (camera, coins, checkerboard), cropped to small
patches purely for illustration.

Pipeline
--------
1.  An H x W grayscale image I is lifted to a piecewise-linear (PL)
    "graph surface" z = I(r,c) over a Union-Jack triangulated grid
    (each unit cell split by its NW-SE diagonal into two triangles).
2.  Each mesh edge e=(p,q) is given an induced Euclidean length in the
    lifted 3-space:  l_e(0) = sqrt( dr^2 + dc^2 + lambda^2 (I_p-I_q)^2 ).
3.  Combinatorial (cone) curvature at every interior vertex is the
    angle defect:  K_v = 2*pi - sum_{triangles t at v} theta_v(t),
    with theta computed from the triangle's edge lengths via the law
    of cosines (discrete Gauss-Bonnet).
4.  A per-vertex conformal factor u is evolved by the multiplicative
    vertex-scaling Yamabe flow
        l_e(u) = exp( (u_p+u_q)/2 ) * l_e(0),      du_v/dt = -(K_v - Kbar_v)
    towards a prescribed target curvature field Kbar (0 for flattening/
    denoising; a scaled copy of K(0) for curvature-amplifying
    enhancement).
5.  The evolved factor field u is mapped back onto intensities,
    I'(v) = clip( I(v) * exp(beta * u_v), 0, 255 ), giving the output
    image.

All routines below are vectorised over triangles/vertices with numpy;
no per-pixel Python loops are used in the numerically heavy steps.
"""

import numpy as np

# ----------------------------------------------------------------------
# 1. Mesh construction
# ----------------------------------------------------------------------

def build_triangles(H, W):
    """Return an (T,3) int array of vertex indices (row*W+col) for the
    Union-Jack triangulation of an H x W grid, split by the NW-SE
    diagonal of every unit cell."""
    r, c = np.meshgrid(np.arange(H - 1), np.arange(W - 1), indexing='ij')
    r = r.ravel(); c = c.ravel()

    def idx(rr, cc):
        return rr * W + cc

    TL = idx(r, c)
    TR = idx(r, c + 1)
    BL = idx(r + 1, c)
    BR = idx(r + 1, c + 1)

    T1 = np.stack([TL, TR, BR], axis=1)   # upper-right triangle
    T2 = np.stack([TL, BR, BL], axis=1)   # lower-left triangle
    return np.concatenate([T1, T2], axis=0)


def vertex_grid_coords(H, W):
    r, c = np.meshgrid(np.arange(H), np.arange(W), indexing='ij')
    return r.ravel().astype(float), c.ravel().astype(float)


# ----------------------------------------------------------------------
# 2. Induced metric (edge lengths) from image intensity
# ----------------------------------------------------------------------

def edge_lengths_for_triangles(tri, I_flat, r, c, lam):
    """For each triangle (T,3) return the 3 edge lengths (a,b,c) with
    a = |v1v2| opposite vertex v0, b = |v0v2| opposite v1, c = |v0v1|
    opposite v2 -- the convention used throughout for law-of-cosines."""
    v0, v1, v2 = tri[:, 0], tri[:, 1], tri[:, 2]

    def elen(p, q):
        dr = r[p] - r[q]
        dc = c[p] - c[q]
        dI = I_flat[p] - I_flat[q]
        return np.sqrt(dr ** 2 + dc ** 2 + (lam * dI) ** 2)

    a = elen(v1, v2)
    b = elen(v0, v2)
    cc = elen(v0, v1)
    return a, b, cc


def triangle_angles(a, b, c):
    """Angles opposite sides a,b,c respectively, via law of cosines.
    Degenerate/near-degenerate triangles are clipped for numerical
    safety (this is the only stabilisation used anywhere in the
    pipeline)."""
    def ang(opp, s1, s2):
        cosv = (s1 ** 2 + s2 ** 2 - opp ** 2) / (2 * s1 * s2 + 1e-12)
        cosv = np.clip(cosv, -1.0, 1.0)
        return np.arccos(cosv)

    A = ang(a, b, c)
    B = ang(b, a, c)
    C = ang(c, a, b)
    return A, B, C


# ----------------------------------------------------------------------
# 3. Combinatorial curvature (discrete Gauss-Bonnet, angle defect)
# ----------------------------------------------------------------------

def vertex_curvature(tri, angles, n_vertices, interior_mask):
    """Accumulate angle sums at each vertex and return
    K_v = 2*pi - angle_sum_v for interior vertices (NaN elsewhere)."""
    A, B, C = angles
    angle_sum = np.zeros(n_vertices)
    np.add.at(angle_sum, tri[:, 0], A)
    np.add.at(angle_sum, tri[:, 1], B)
    np.add.at(angle_sum, tri[:, 2], C)

    K = np.full(n_vertices, np.nan)
    K[interior_mask] = 2 * np.pi - angle_sum[interior_mask]
    return K, angle_sum


def interior_mask_for(H, W):
    m = np.zeros((H, W), dtype=bool)
    m[1:-1, 1:-1] = True
    return m.ravel()


# ----------------------------------------------------------------------
# 4. Discrete combinatorial Yamabe flow
# ----------------------------------------------------------------------

def curvature_from_u(tri, l0, u, r, c, lam):
    """Given base lengths l0=(a0,b0,c0) per triangle and a vertex
    conformal-factor field u, return the rescaled lengths and the
    resulting per-vertex curvature."""
    v0, v1, v2 = tri[:, 0], tri[:, 1], tri[:, 2]
    a0, b0, c0 = l0

    a = np.exp((u[v1] + u[v2]) / 2.0) * a0
    b = np.exp((u[v0] + u[v2]) / 2.0) * b0
    cc = np.exp((u[v0] + u[v1]) / 2.0) * c0
    return a, b, cc


def yamabe_flow(H, W, I_flat, lam=0.35, target='flat', amp=1.6,
                 n_steps=60, dt=0.05, clip_u=3.0):
    """Run the discrete Yamabe flow.

    target: 'flat'  -> Kbar = 0 everywhere (denoising / smoothing flow)
            'amp'   -> Kbar = amp * K(0)   (curvature-amplifying /
                                              enhancement flow)
    Returns dict with trajectories needed for the figures.
    """
    r, c = vertex_grid_coords(H, W)
    tri = build_triangles(H, W)
    n_vertices = H * W
    int_mask = interior_mask_for(H, W)

    a0, b0, c0 = edge_lengths_for_triangles(tri, I_flat, r, c, lam)
    A0, B0, C0 = triangle_angles(a0, b0, c0)
    K0, _ = vertex_curvature(tri, (A0, B0, C0), n_vertices, int_mask)

    if target == 'flat':
        Kbar = np.zeros(n_vertices)
    else:
        Kbar = amp * np.nan_to_num(K0)

    u = np.zeros(n_vertices)
    energy_hist = []
    K = K0.copy()
    u_hist = []
    K_hist = [K0.copy()]

    for step in range(n_steps):
        Kc = np.nan_to_num(K)
        grad = -(Kc - Kbar)
        grad[~int_mask] = 0.0
        u = u + dt * grad
        u = np.clip(u, -clip_u, clip_u)

        a, b, cc = curvature_from_u(tri, (a0, b0, c0), u, r, c, lam)
        Aa, Bb, Cc = triangle_angles(a, b, cc)
        K, _ = vertex_curvature(tri, (Aa, Bb, Cc), n_vertices, int_mask)

        dev = np.nan_to_num(K - Kbar)
        energy_hist.append(float(np.sum(dev[int_mask] ** 2)))
        if step % max(1, n_steps // 6) == 0 or step == n_steps - 1:
            u_hist.append(u.copy())
            K_hist.append(K.copy())

    return {
        'K0': K0, 'Kfinal': K, 'u': u, 'tri': tri,
        'energy_hist': np.array(energy_hist),
        'u_hist': u_hist, 'K_hist': K_hist,
        'int_mask': int_mask,
        'l0': (a0, b0, c0), 'r': r, 'c': c, 'lam': lam,
    }



def reconstruct_image(I, u, H, W, beta=0.9, mode='multiplicative'):
    """Simple (non-Poisson) reconstruction used for the enhancement flow,
    where a direct multiplicative contrast boost at high-curvature
    vertices is exactly what is wanted (Section 6, enhancement flow)."""
    u_img = u.reshape(H, W)
    if mode == 'multiplicative':
        out = I.astype(float) * np.exp(beta * u_img)
    else:
        out = I.astype(float) + beta * 255.0 * u_img
    return np.clip(out, 0, 255)


# ----------------------------------------------------------------------
# 5. Poisson (gradient-domain) reconstruction for the flattening flow
# ----------------------------------------------------------------------
#
# The flattening flow changes edge *lengths*, not pixel intensities
# directly. The correct way to read an intensity field back out of the
# flowed metric is to solve for the image whose intensity differences
# best reproduce, in the least-squares sense, the differences implied
# by the flowed edge lengths -- a graph-Poisson / gradient-domain
# reconstruction in the spirit of Perez-Gangnet-Blake Poisson image
# editing. This is what is used for the flattening-flow denoising
# results (Section 6); the multiplicative rule above remains adequate
# for the enhancement flow, where amplifying (not undoing) curvature is
# exactly the goal.

from scipy import sparse
from scipy.sparse.linalg import cg


def unique_edges(tri):
    e = np.concatenate([tri[:, [0, 1]], tri[:, [1, 2]], tri[:, [0, 2]]], axis=0)
    e = np.sort(e, axis=1)
    e = np.unique(e, axis=0)
    return e


def reconstruct_poisson(I_flat, u, H, W, tri, l0, r, c, lam, reg=1e-2):
    """Solve  L I' = b  (graph Poisson equation) where the target edge
    differences are read off from the Yamabe-flowed edge lengths.
    `reg` is a small Tikhonov term pinning the mean intensity, needed
    because a pure gradient-domain system is only defined up to an
    additive constant."""
    a0, b0, c0 = l0
    edges = unique_edges(tri)
    p, q = edges[:, 0], edges[:, 1]

    dr = r[p] - r[q]
    dc = c[p] - c[q]
    dI0 = I_flat[p] - I_flat[q]
    l_base = np.sqrt(dr ** 2 + dc ** 2 + (lam * dI0) ** 2)

    up, uq = u[p], u[q]
    l_new = np.exp((up + uq) / 2.0) * l_base

    spatial2 = dr ** 2 + dc ** 2
    dI_target_sq = np.maximum(l_new ** 2 - spatial2, 0.0) / (lam ** 2 + 1e-12)
    dI_target = np.sign(dI0) * np.sqrt(dI_target_sq)
    dI_target = np.where(dI0 == 0, 0.0, dI_target)

    n = H * W
    w = np.ones(len(edges))

    rows = np.concatenate([p, q, p, q])
    cols = np.concatenate([p, q, q, p])
    data = np.concatenate([w, w, -w, -w])
    L = sparse.coo_matrix((data, (rows, cols)), shape=(n, n)).tocsr()
    L = L + reg * sparse.identity(n)

    b = np.zeros(n)
    np.add.at(b, p, w * dI_target)
    np.add.at(b, q, -w * dI_target)
    b = b + reg * I_flat

    I_new, info = cg(L, b, x0=I_flat, rtol=1e-6, maxiter=500)
    return np.clip(I_new.reshape(H, W), 0, 255)
